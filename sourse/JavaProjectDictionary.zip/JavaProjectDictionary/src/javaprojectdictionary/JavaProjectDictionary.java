
package javaprojectdictionary;

import java.awt.Font;
import java.io.IOException;


public class JavaProjectDictionary {
    
    
     
    public static void main(String[] args) throws IOException {
    
     
    DictGui dg = new DictGui();
     dg.setLocation(200,100);
     dg.setVisible(true);
    
    dg.setResizable(false);
       dg.showTime();
        
     


      
    }
    
}
